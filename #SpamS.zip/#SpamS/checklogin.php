<?php

	session_start();

	if ($_SESSION['access']==1){
		echo 1;
	}else{
		echo 0;
	}

?>