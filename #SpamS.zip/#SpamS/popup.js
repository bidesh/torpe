

function itemsList(){

        var xmlhttp;
        var message;   
        //var value = "x"; 
        if (window.XMLHttpRequest)
          {// code for IE7+, Firefox, Chrome, Opera, Safari
          xmlhttp=new XMLHttpRequest();
          }
        else
          {// code for IE6, IE5
          xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
          }
        xmlhttp.onreadystatechange=function()
          {
          if (xmlhttp.readyState==4 && xmlhttp.status==200)
            {
            //document.getElementById("value").innerHTML = xmlhttp.responseText;
            message = xmlhttp.responseText;


            document.getElementById("items").innerHTML = message;

         
        }
        
          }
      xmlhttp.open("GET","http://torpe.user.jacobs-university.de/extquery.php?q=list",true);
      xmlhttp.send();

}








document.addEventListener('DOMContentLoaded', function () {
  //getSales.checkLoggedin();
  //getSales.itemsList();
  //checkLoggedin();
  itemsList();
});



