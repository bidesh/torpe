//var overlay = "10";

//chrome.browserAction.setBadgeText({ text: "10" });

count = "x";
function itemsCount()
{
	var xmlhttp;   
	var value = "x"; 
	if (window.XMLHttpRequest)
	  {// code for IE7+, Firefox, Chrome, Opera, Safari
	  xmlhttp=new XMLHttpRequest();
	  }
	else
	  {// code for IE6, IE5
	  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	xmlhttp.onreadystatechange=function()
	  {
	  if (xmlhttp.readyState==4 && xmlhttp.status==200)
	    {
	     //document.getElementById("value").innerHTML = xmlhttp.responseText;
	     count =xmlhttp.responseText;

	     if(count== "Not Logged in"){
	     		count = "x";
	     }

	     chrome.browserAction.setBadgeText({ text: count});
	     //document.getElementById("test").innerHTML = count;
	     //return value;
	     itemsCount();
	     
	    }
	    
	  }
	xmlhttp.open("GET","http://torpe.user.jacobs-university.de/extquery.php?q=count",true);
	xmlhttp.send();
	
}
itemsCount();
